Use defaultdb;
drop database defaultdb;